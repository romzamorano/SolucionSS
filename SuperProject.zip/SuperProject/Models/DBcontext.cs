﻿using Microsoft.EntityFrameworkCore;

namespace SuperProject.Models
{
    public partial class DBcontext : DbContext
    {
        public DBcontext(DbContextOptions
               <DBcontext> options)
                   : base(options)
        {
        }
        public virtual DbSet<User> User { get; set; }
        public virtual DbSet<Events> Events { get; set; }
        public virtual DbSet<Ticket> Ticket { get; set; }
        public virtual DbSet<Order> Order { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>(entity => {
                entity.HasKey(k => k.UserId);
            });
            
            modelBuilder.Entity<Events>(entity => {
                entity.HasKey(k => k.EventId);
            });

            modelBuilder.Entity<Ticket>(entity =>
            {
                entity.HasKey(k => k.TicketId);
            });

            modelBuilder.Entity<Order>(entity =>
            {
                entity.HasKey(k => k.OrderId);
            });

            OnModelCreatingPartial(modelBuilder);
        }
        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
