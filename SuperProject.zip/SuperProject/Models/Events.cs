﻿using System.ComponentModel.DataAnnotations;

namespace SuperProject.Models
{
    public class Events
    {

        [Key]
        public int EventId { get; set; }

        [Required]
        [MaxLength(200)]
        public string Name { get; set; }

        [Required]
        public string Location { get; set; }

        [Required]
        public DateTime Date { get; set; }

        [Required]
        public string Artist { get; set; }

    }
}
