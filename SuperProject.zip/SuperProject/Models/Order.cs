﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SuperProject.Models
{
    public class Order
    {
        [Key]
        public int OrderId { get; set; }

        [ForeignKey("User")]
        public int UserId { get; set; }

        [ForeignKey("Ticket")]
        public int TicketId { get; set; }

        [Required]
        public int Total { get; set; }

        [Required]
        public DateTime OrderDate { get; set; }
    }
}
