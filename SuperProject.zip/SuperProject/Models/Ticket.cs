﻿using Microsoft.Extensions.Diagnostics.HealthChecks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SuperProject.Models
{
    public class Ticket
    {
        [Key]
        public int TicketId { get; set; }

        [ForeignKey("Events")]
        public int EventId { get; set; }

        [Required]
        public string Section { get; set; }

        public string Seat { get; set; }

        [Required]
        public int Price { get; set; }
    }
}
