﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using SuperProject.Models;

namespace SuperProject.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TicketController : ControllerBase
    {
        private readonly DBcontext _context;
        public TicketController(DBcontext context)
        {
            _context = context;
        }

        // GET: api/Ticket
        [HttpGet]
        public ActionResult<IEnumerable<Ticket>> GetTicket()
        {
            return _context.Ticket.ToList();
        }

        // GET: api/Ticket/1
        [HttpGet("{id}")]
        public ActionResult<Ticket> GetTicket(int id)
        {
            var ticket = _context.Ticket.Find(id);
            if (ticket == null)
            {
                return NotFound();
            }
            return ticket;
        }

        // POST: api/Ticket
        [HttpPost]
        public ActionResult<Ticket> CreateTicket(Ticket ticket)
        {
            if (ticket == null)
            {
                return BadRequest();
            }
            _context.Ticket.Add(ticket);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetTicket), new { id = ticket.TicketId }, ticket);
        }
    }
}
