﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SuperProject.Models;

namespace SuperProject.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OrderController : ControllerBase
    {
        private readonly DBcontext _context;
        public OrderController(DBcontext context)
        {
            _context = context;
        }

        // GET: api/Order
        [HttpGet]
        public ActionResult<IEnumerable<Order>> GetOrder()
        {
            return _context.Order.ToList();
        }

        // GET: api/Order/1
        [HttpGet("{id}")]
        public ActionResult<Order> GetOrder(int id)
        {
            var order = _context.Order.Find(id);
            if (order == null)
            {
                return NotFound();
            }
            return order;
        }

        // GET: api/Order/2
        [HttpGet("userOrders/{userId}")]
        public ActionResult<IEnumerable<Order>> GetOrderByUser(int userId)
        {
            return _context.Order.Where(order => order.UserId == userId).ToList();
        }

        // POST: api/Order
        [HttpPost]
        public ActionResult<Order> CreateOrder(Order order)
        {
            if (order == null)
            {
                return BadRequest();
            }
            _context.Order.Add(order);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetOrder), new { id = order.OrderId }, order);
        }

        [HttpDelete("{id}")]
        public string DeleteOrder(int id) 
        {
            Order order = GetOrder(id).Value;

           if ( (DateTime.Now - order.OrderDate).TotalHours > 48)
            {
                return "Ya no puedes cancelar la orden";
            }
           else
            {
                _context.Order.Remove(order);
                _context.SaveChanges();
                return "Orden cancelada";
            }

        }
    }
}
