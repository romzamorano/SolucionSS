﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using SuperProject.Models;

namespace SuperProject.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EventsController : ControllerBase
    {
        private readonly DBcontext _context;
        public EventsController(DBcontext context)
        {
            _context = context;
        }

        // GET: api/Events
        [HttpGet]
        public ActionResult<IEnumerable<Events>> GetEvents()
        {
            return _context.Events.ToList();
        }

        // GET: api/Events/1
        [HttpGet("{id}")]
        public ActionResult<Events> GetEvents(int id)
        {
            var events = _context.Events.Find(id);
            if (events == null)
            {
                return NotFound();
            }
            return events;
        }

        // POST: api/Events
        [HttpPost]
        public ActionResult<Events> CreateEvents(Events events)
        {
            if (events == null)
            {
                return BadRequest();
            }
            _context.Events.Add(events);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetEvents), new { id = events.EventId }, events);
        }
    }
}
